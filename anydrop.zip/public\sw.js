// AnyDrop Service Worker for offline capability & fast loading
const CACHE_NAME = 'anydrop-v1';
const ASSETS = [
    './',
    './index.html',
    './style.css',
    './app.js',
    './qrcode.js',
    './manifest.json',
    './icon.svg'
];

self.addEventListener('install', (e) => {
    e.waitUntil(
        caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
    );
    self.skipWaiting();
});

self.addEventListener('activate', (e) => {
    e.waitUntil(
        caches.keys().then((keys) => {
            return Promise.all(
                keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
            );
        })
    );
    self.clients.claim();
});

self.addEventListener('fetch', (e) => {
    // Only cache static assets, not WebSocket or API calls
    if (e.request.url.includes('/api/') || e.request.url.startsWith('ws')) {
        return;
    }

    e.respondWith(
        caches.match(e.request).then((res) => {
            return res || fetch(e.request).catch(() => caches.match('./index.html'));
        })
    );
});
