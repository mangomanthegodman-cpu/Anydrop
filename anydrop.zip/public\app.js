/**
 * AnyDrop - Universal Cross-Platform Anywhere File Transfer Client
 * Works across PC, iOS, and Android on ANY network (5G, LTE, Wi-Fi, Internet)
 */

(function () {
    'use strict';

    // -------------------------------------------------------------------------
    // Configuration & Constants
    // -------------------------------------------------------------------------
    const CHUNK_SIZE = 64 * 1024; // 64 KB chunks
    const BUFFER_HIGH_WATERMARK = 4 * 1024 * 1024; // 4 MB flow control threshold

    // Comprehensive STUN + OpenRelay TURN configuration for ANY network (5G / LTE / NAT)
    const ICE_CONFIG = {
        iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' },
            { urls: 'stun:stun2.l.google.com:19302' },
            { urls: 'stun:stun.cloudflare.com:3478' },
            { urls: 'stun:global.stun.twilio.com:3478' },
            { urls: 'stun:stun.services.mozilla.com' },
            {
                urls: 'turn:openrelay.metered.ca:80',
                username: 'openrelayproject',
                credential: 'openrelayproject'
            },
            {
                urls: 'turn:openrelay.metered.ca:443',
                username: 'openrelayproject',
                credential: 'openrelayproject'
            },
            {
                urls: 'turn:openrelay.metered.ca:443?transport=tcp',
                username: 'openrelayproject',
                credential: 'openrelayproject'
            }
        ],
        iceCandidatePoolSize: 10
    };

    // -------------------------------------------------------------------------
    // Application State
    // -------------------------------------------------------------------------
    const state = {
        role: 'sender',
        roomId: generateRoomCode(),
        myClientId: null,
        targetPeerId: null,
        deviceType: detectDevice(),
        reachableBaseUrl: window.location.origin,
        isGlobalMode: false,
        
        // Selected files for sending
        filesToSend: [],
        
        // Active transfer state
        isTransferring: false,
        activeChannelType: 'webrtc', // 'webrtc' | 'relay'
        currentFileIndex: 0,
        transferredBytes: 0,
        totalBytes: 0,
        transferStartTime: 0,
        lastBytesCheck: 0,
        lastTimeCheck: 0,
        currentSpeed: 0,
        
        // Receiving state
        receivedFiles: [],
        incomingMeta: null,
        receiveBuffer: [],
        receivedFileBytes: 0,
        autoDownload: true,

        // Networking
        ws: null,
        peerConnection: null,
        dataChannel: null,
        isWebRTCConnected: false
    };

    // -------------------------------------------------------------------------
    // DOM Element References
    // -------------------------------------------------------------------------
    const els = {
        brandBtn: document.getElementById('brandBtn'),
        pillSenderBtn: document.getElementById('pillSenderBtn'),
        pillReceiverBtn: document.getElementById('pillReceiverBtn'),
        statusBadge: document.getElementById('statusBadge'),
        statusText: document.getElementById('statusText'),
        themeToggleBtn: document.getElementById('themeToggleBtn'),
        currentDeviceChip: document.getElementById('currentDeviceChip'),
        deviceIcon: document.getElementById('deviceIcon'),
        deviceText: document.getElementById('deviceText'),
        networkChip: document.getElementById('networkChip'),

        // Panels
        roleSelectorView: document.getElementById('roleSelectorView'),
        senderView: document.getElementById('senderView'),
        receiverView: document.getElementById('receiverView'),
        switchToReceiverLink: document.getElementById('switchToReceiverLink'),
        switchToSenderLink: document.getElementById('switchToSenderLink'),
        chooseSenderCard: document.getElementById('chooseSenderCard'),
        chooseReceiverCard: document.getElementById('chooseReceiverCard'),

        // Sender elements
        senderRoomCode: document.getElementById('senderRoomCode'),
        senderPeerStatus: document.getElementById('senderPeerStatus'),
        copyCodeBtn: document.getElementById('copyCodeBtn'),
        showQrBtn: document.getElementById('showQrBtn'),
        shareLinkBtn: document.getElementById('shareLinkBtn'),
        targetReceiverCodeInput: document.getElementById('targetReceiverCodeInput'),
        joinReceiverBtn: document.getElementById('joinReceiverBtn'),

        // Storage & Drop Zone
        dropZone: document.getElementById('dropZone'),
        genericFileInput: document.getElementById('genericFileInput'),
        mediaFileInput: document.getElementById('mediaFileInput'),
        cameraFileInput: document.getElementById('cameraFileInput'),
        fileCountBadge: document.getElementById('fileCountBadge'),
        selectedFilesSection: document.getElementById('selectedFilesSection'),
        selectedFilesList: document.getElementById('selectedFilesList'),
        clearAllFilesBtn: document.getElementById('clearAllFilesBtn'),
        startTransferBtn: document.getElementById('startTransferBtn'),
        startTransferBtnText: document.getElementById('startTransferBtnText'),

        // Receiver elements
        receiverQrFrame: document.getElementById('receiverQrFrame'),
        receiverRoomCode: document.getElementById('receiverRoomCode'),
        copyReceiverCodeBtn: document.getElementById('copyReceiverCodeBtn'),
        shareReceiverLinkBtn: document.getElementById('shareReceiverLinkBtn'),
        targetSenderCodeInput: document.getElementById('targetSenderCodeInput'),
        joinSenderBtn: document.getElementById('joinSenderBtn'),
        autoDownloadToggle: document.getElementById('autoDownloadToggle'),
        receiverStatusTitle: document.getElementById('receiverStatusTitle'),
        receiverStatusDesc: document.getElementById('receiverStatusDesc'),
        receivedFilesCard: document.getElementById('receivedFilesCard'),
        receivedFilesList: document.getElementById('receivedFilesList'),
        saveAllReceivedBtn: document.getElementById('saveAllReceivedBtn'),

        // Modals
        qrModal: document.getElementById('qrModal'),
        closeQrModal: document.getElementById('closeQrModal'),
        modalQrCodeContainer: document.getElementById('modalQrCodeContainer'),
        modalQrCodeText: document.getElementById('modalQrCodeText'),
        copyModalLinkBtn: document.getElementById('copyModalLinkBtn'),

        incomingModal: document.getElementById('incomingModal'),
        incomingSenderName: document.getElementById('incomingSenderName'),
        incomingMetaText: document.getElementById('incomingMetaText'),
        incomingFilesPreview: document.getElementById('incomingFilesPreview'),
        declineTransferBtn: document.getElementById('declineTransferBtn'),
        acceptTransferBtn: document.getElementById('acceptTransferBtn'),

        transferProgressModal: document.getElementById('transferProgressModal'),
        transferModalTitle: document.getElementById('transferModalTitle'),
        transferChannelBadge: document.getElementById('transferChannelBadge'),
        activeFileName: document.getElementById('activeFileName'),
        transferFileCounter: document.getElementById('transferFileCounter'),
        transferProgressBar: document.getElementById('transferProgressBar'),
        transferPercent: document.getElementById('transferPercent'),
        transferSpeed: document.getElementById('transferSpeed'),
        transferTimeRemaining: document.getElementById('transferTimeRemaining'),
        transferBytes: document.getElementById('transferBytes'),
        cancelTransferBtn: document.getElementById('cancelTransferBtn'),

        infoModal: document.getElementById('infoModal'),
        howItWorksBtn: document.getElementById('howItWorksBtn'),
        closeInfoModal: document.getElementById('closeInfoModal'),
        closeInfoModalBtn: document.getElementById('closeInfoModalBtn'),

        toastContainer: document.getElementById('toastContainer')
    };

    // -------------------------------------------------------------------------
    // Device & Environment Detection
    // -------------------------------------------------------------------------
    function detectDevice() {
        const ua = navigator.userAgent;
        if (/iPad|iPhone|iPod/.test(ua) && !window.MSStream) {
            return { os: 'ios', name: 'iOS Device (iPhone/iPad)', icon: '📱' };
        }
        if (/Android/.test(ua)) {
            return { os: 'android', name: 'Android Device', icon: '📱' };
        }
        if (/Macintosh|Mac OS X/.test(ua)) {
            return { os: 'mac', name: 'Mac Computer', icon: '💻' };
        }
        if (/Windows/.test(ua)) {
            return { os: 'windows', name: 'Windows PC', icon: '🖥️' };
        }
        return { os: 'desktop', name: 'Computer / Browser', icon: '💻' };
    }

    function generateRoomCode() {
        const num1 = Math.floor(100 + Math.random() * 900);
        const num2 = Math.floor(100 + Math.random() * 900);
        return `${num1}-${num2}`;
    }

    function formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    function formatTime(seconds) {
        if (isNaN(seconds) || seconds < 0 || !isFinite(seconds)) return '--';
        if (seconds < 60) return `${Math.ceil(seconds)}s left`;
        const mins = Math.floor(seconds / 60);
        const secs = Math.ceil(seconds % 60);
        return `${mins}m ${secs}s left`;
    }

    function getFileIcon(filename) {
        const ext = filename.split('.').pop().toLowerCase();
        if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'heic'].includes(ext)) return '🖼️';
        if (['mp4', 'mov', 'avi', 'mkv', 'webm', '3gp'].includes(ext)) return '🎥';
        if (['mp3', 'wav', 'aac', 'flac', 'm4a', 'ogg'].includes(ext)) return '🎵';
        if (['pdf'].includes(ext)) return '📕';
        if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) return '📦';
        if (['doc', 'docx', 'txt', 'rtf', 'odt'].includes(ext)) return '📄';
        if (['xls', 'xlsx', 'csv'].includes(ext)) return '📊';
        if (['apk'].includes(ext)) return '🤖';
        return '📁';
    }

    // -------------------------------------------------------------------------
    // Audio Synthesizer (Zero-asset sound effects)
    // -------------------------------------------------------------------------
    const sound = {
        ctx: null,
        init() {
            try {
                if (!this.ctx) {
                    const AudioContext = window.AudioContext || window.webkitAudioContext;
                    if (AudioContext) this.ctx = new AudioContext();
                }
                if (this.ctx && this.ctx.state === 'suspended') {
                    this.ctx.resume();
                }
            } catch (e) {}
        },
        playChime() {
            this.init();
            if (!this.ctx) return;
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'sine';
            osc.frequency.setValueAtTime(587.33, now);
            osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);

            gain.gain.setValueAtTime(0.15, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.45);
        },
        playAlert() {
            this.init();
            if (!this.ctx) return;
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'triangle';
            osc.frequency.setValueAtTime(440, now);
            osc.frequency.setValueAtTime(659.25, now + 0.12);

            gain.gain.setValueAtTime(0.18, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.35);
        }
    };

    function triggerHaptic() {
        if ('vibrate' in navigator) {
            try { navigator.vibrate([40, 60, 40]); } catch (e) {}
        }
    }

    function showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        const icons = { info: '💡', success: '✅', warning: '⚠️', error: '❌' };
        toast.innerHTML = `<span>${icons[type] || '💡'}</span> <span>${message}</span>`;
        els.toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(10px) scale(0.95)';
            toast.style.transition = 'all 0.25s ease';
            setTimeout(() => toast.remove(), 250);
        }, 3200);
    }

    // -------------------------------------------------------------------------
    // Network Info & URL Resolution for Any Network
    // -------------------------------------------------------------------------
    async function fetchServerInfo() {
        try {
            const res = await fetch('/api/info');
            if (res.ok) {
                const data = await res.json();
                if (data.publicUrl) {
                    state.reachableBaseUrl = data.publicUrl;
                    state.isGlobalMode = true;
                    updateNetworkChip('global', '🌍 Any Network (Global Public HTTPS)');
                } else if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
                    if (data.ips && data.ips.length > 0) {
                        state.reachableBaseUrl = `http://${data.ips[0].address}:${data.port}`;
                        updateNetworkChip('local', `📶 Wi-Fi (${data.ips[0].address})`);
                    }
                } else {
                    state.reachableBaseUrl = window.location.origin;
                    updateNetworkChip('active', `🌐 Network: ${window.location.hostname}`);
                }
                updateUIForActiveRoom();
            }
        } catch (e) {
            console.log('Using standard origin for share links');
        }
    }

    function updateNetworkChip(type, text) {
        if (!els.networkChip) return;
        const dot = els.networkChip.querySelector('.pulse-ring');
        if (dot) {
            dot.style.background = type === 'global' ? '#10b981' : '#38bdf8';
            dot.style.boxShadow = `0 0 8px ${type === 'global' ? '#10b981' : '#38bdf8'}`;
        }
        const span = els.networkChip.querySelector('span:not(.pulse-ring)');
        if (span) span.textContent = text;
    }

    function getShareableURL(role, roomCode) {
        try {
            const base = new URL(state.reachableBaseUrl);
            base.pathname = window.location.pathname;
            base.hash = `room=${roomCode}&role=${role === 'sender' ? 'receiver' : 'sender'}`;
            return base.toString();
        } catch (e) {
            const url = new URL(window.location.href);
            url.hash = `room=${roomCode}&role=${role === 'sender' ? 'receiver' : 'sender'}`;
            return url.toString();
        }
    }

    function renderQRCode(targetEl, text) {
        if (!targetEl) return;
        if (typeof window.createQRCodeSVG === 'function') {
            targetEl.innerHTML = window.createQRCodeSVG(text, 5, 8);
        } else {
            targetEl.innerHTML = `<div style="padding: 20px; font-size: 11px; word-break: break-all;">${text}</div>`;
        }
    }

    // -------------------------------------------------------------------------
    // WebSocket Signaling & Networking
    // -------------------------------------------------------------------------
    function connectSignalingServer() {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const host = window.location.host;
        const wsUrl = `${protocol}//${host}`;

        try {
            state.ws = new WebSocket(wsUrl);
            state.ws.binaryType = 'arraybuffer';

            state.ws.onopen = () => {
                updateConnectionStatus('online', 'Connected (Anywhere Ready)');
                joinRoom(state.roomId, state.role);
            };

            state.ws.onmessage = (event) => {
                if (typeof event.data === 'string') {
                    try {
                        const message = JSON.parse(event.data);
                        handleSignalingMessage(message);
                    } catch (e) {
                        console.error('Failed to parse WS message:', e);
                    }
                } else if (event.data instanceof ArrayBuffer) {
                    handleReceivedBinaryChunk(event.data);
                }
            };

            state.ws.onclose = () => {
                updateConnectionStatus('offline', 'Reconnecting...');
                setTimeout(connectSignalingServer, 3000);
            };

            state.ws.onerror = () => {
                updateConnectionStatus('offline', 'Offline');
            };
        } catch (err) {
            console.error('WebSocket connection error:', err);
            updateConnectionStatus('offline', 'Signaling Offline');
        }
    }

    function updateConnectionStatus(type, text) {
        const dot = els.statusBadge.querySelector('.status-dot');
        dot.className = `status-dot ${type}`;
        els.statusText.textContent = text;
    }

    function sendWs(data) {
        if (state.ws && state.ws.readyState === WebSocket.OPEN) {
            state.ws.send(typeof data === 'string' ? data : JSON.stringify(data));
        }
    }

    function joinRoom(roomId, role) {
        state.roomId = roomId.toUpperCase().trim();
        state.role = role;

        sendWs({
            type: 'join',
            roomId: state.roomId,
            role: state.role
        });

        updateUIForActiveRoom();
    }

    // -------------------------------------------------------------------------
    // WebRTC Setup with Multi-STUN & TURN for ANY Network
    // -------------------------------------------------------------------------
    function createPeerConnection(targetPeerId) {
        if (state.peerConnection) {
            try { state.peerConnection.close(); } catch (e) {}
        }

        state.targetPeerId = targetPeerId;
        state.peerConnection = new RTCPeerConnection(ICE_CONFIG);
        state.isWebRTCConnected = false;

        state.peerConnection.onicecandidate = (event) => {
            if (event.candidate) {
                sendWs({
                    type: 'signal',
                    targetPeerId: targetPeerId,
                    signalData: { candidate: event.candidate }
                });
            }
        };

        state.peerConnection.onconnectionstatechange = () => {
            const connState = state.peerConnection.connectionState;
            console.log('WebRTC connection state:', connState);

            if (connState === 'connected') {
                state.isWebRTCConnected = true;
                updatePeerConnectionUI(true, 'Direct P2P Encrypted');
                showToast('Connected direct P2P!', 'success');
            } else if (connState === 'failed' || connState === 'disconnected') {
                state.isWebRTCConnected = false;
                updatePeerConnectionUI(true, 'Cloud Relay (Guaranteed)');
            }
        };

        if (state.role === 'sender') {
            setupDataChannel(state.peerConnection.createDataChannel('anydropTransfer', { ordered: true }));
        } else {
            state.peerConnection.ondatachannel = (event) => {
                setupDataChannel(event.channel);
            };
        }
    }

    function setupDataChannel(channel) {
        state.dataChannel = channel;
        state.dataChannel.binaryType = 'arraybuffer';
        state.dataChannel.bufferedAmountLowThreshold = 1024 * 1024;

        state.dataChannel.onopen = () => {
            state.isWebRTCConnected = true;
            updatePeerConnectionUI(true, 'Direct P2P Ready');
        };

        state.dataChannel.onmessage = (event) => {
            if (typeof event.data === 'string') {
                try {
                    const msg = JSON.parse(event.data);
                    handleTransferControlMessage(msg);
                } catch (e) {}
            } else if (event.data instanceof ArrayBuffer) {
                handleReceivedBinaryChunk(event.data);
            }
        };

        state.dataChannel.onclose = () => {
            state.isWebRTCConnected = false;
        };
    }

    async function initiateWebRTCOffer(targetPeerId) {
        createPeerConnection(targetPeerId);

        try {
            const offer = await state.peerConnection.createOffer();
            await state.peerConnection.setLocalDescription(offer);

            sendWs({
                type: 'signal',
                targetPeerId: targetPeerId,
                signalData: { sdp: state.peerConnection.localDescription }
            });
        } catch (err) {
            console.error('Failed to create WebRTC offer:', err);
        }
    }

    async function handleSignalingMessage(message) {
        switch (message.type) {
            case 'welcome':
                state.myClientId = message.clientId;
                break;

            case 'joined':
                state.roomId = message.roomId;
                updateUIForActiveRoom();

                if (message.peers && message.peers.length > 0) {
                    const peer = message.peers[0];
                    state.targetPeerId = peer.id;
                    updatePeerConnectionUI(true, `Paired with ${peer.role}`);

                    if (state.role === 'sender') {
                        initiateWebRTCOffer(peer.id);
                    }
                }
                break;

            case 'peer-joined':
                state.targetPeerId = message.peerId;
                updatePeerConnectionUI(true, `Paired with ${message.role}`);
                showToast(`${message.role.toUpperCase()} connected to room!`, 'success');
                sound.playChime();

                if (state.role === 'sender') {
                    initiateWebRTCOffer(message.peerId);
                }
                break;

            case 'peer-left':
                state.targetPeerId = null;
                updatePeerConnectionUI(false, 'Waiting for peer...');
                showToast('Counterpart disconnected', 'warning');
                break;

            case 'signal':
                handleSignalData(message.fromPeerId, message.signalData);
                break;

            case 'file-meta':
                handleIncomingFileMeta(message);
                break;

            case 'transfer-accept':
                handleTransferAccepted();
                break;

            case 'transfer-decline':
                handleTransferDeclined();
                break;

            case 'transfer-cancel':
                handleTransferCancelled();
                break;

            case 'start-file':
            case 'end-file':
            case 'transfer-complete':
                handleTransferControlMessage(message);
                break;
        }
    }

    async function handleSignalData(fromPeerId, signal) {
        if (!state.peerConnection) {
            createPeerConnection(fromPeerId);
        }

        try {
            if (signal.sdp) {
                await state.peerConnection.setRemoteDescription(new RTCSessionDescription(signal.sdp));

                if (signal.sdp.type === 'offer') {
                    const answer = await state.peerConnection.createAnswer();
                    await state.peerConnection.setLocalDescription(answer);

                    sendWs({
                        type: 'signal',
                        targetPeerId: fromPeerId,
                        signalData: { sdp: state.peerConnection.localDescription }
                    });
                }
            } else if (signal.candidate) {
                await state.peerConnection.addIceCandidate(new RTCIceCandidate(signal.candidate));
            }
        } catch (err) {
            console.error('Error handling WebRTC signal:', err);
        }
    }

    function updatePeerConnectionUI(isConnected, statusText) {
        const dotSender = els.senderPeerStatus.querySelector('.dot');

        if (isConnected) {
            if (dotSender) {
                dotSender.className = 'dot green';
                els.senderPeerStatus.innerHTML = `<span class="dot green"></span> Connected (${statusText || 'Ready'})`;
            }
            els.receiverStatusTitle.textContent = 'Connected with Sender!';
            els.receiverStatusDesc.textContent = `Ready to beam files directly into device storage (${statusText || 'Any Network'}).`;
        } else {
            if (dotSender) {
                dotSender.className = 'dot yellow';
                els.senderPeerStatus.innerHTML = `<span class="dot yellow"></span> Waiting for Receiver`;
            }
            els.receiverStatusTitle.textContent = 'Waiting for sender to beam files...';
            els.receiverStatusDesc.textContent = 'Keep this page open on your phone or PC.';
        }
    }

    // -------------------------------------------------------------------------
    // Room & UI Management
    // -------------------------------------------------------------------------
    function updateUIForActiveRoom() {
        els.senderRoomCode.textContent = state.roomId;
        els.receiverRoomCode.textContent = state.roomId;

        const shareUrl = getShareableURL(state.role, state.roomId);
        renderQRCode(els.receiverQrFrame, shareUrl);

        if (els.modalQrCodeText) {
            els.modalQrCodeText.textContent = `Room Code: ${state.roomId}`;
            renderQRCode(els.modalQrCodeContainer, shareUrl);
        }
    }

    function setRole(newRole) {
        state.role = newRole;

        if (newRole === 'sender') {
            els.pillSenderBtn.classList.add('active');
            els.pillReceiverBtn.classList.remove('active');
            els.senderView.style.display = 'flex';
            els.receiverView.style.display = 'none';
            els.roleSelectorView.style.display = 'none';
        } else {
            els.pillReceiverBtn.classList.add('active');
            els.pillSenderBtn.classList.remove('active');
            els.receiverView.style.display = 'flex';
            els.senderView.style.display = 'none';
            els.roleSelectorView.style.display = 'none';
        }

        joinRoom(state.roomId, newRole);
    }

    // -------------------------------------------------------------------------
    // Phone Storage & File Selection Handling
    // -------------------------------------------------------------------------
    function addFilesToQueue(fileList) {
        if (!fileList || fileList.length === 0) return;

        for (let i = 0; i < fileList.length; i++) {
            const file = fileList[i];
            const exists = state.filesToSend.some(f => f.name === file.name && f.size === file.size);
            if (!exists) {
                state.filesToSend.push(file);
            }
        }

        renderSelectedFilesList();
        showToast(`Added ${fileList.length} file(s) to queue`, 'info');
    }

    function renderSelectedFilesList() {
        els.selectedFilesList.innerHTML = '';

        if (state.filesToSend.length === 0) {
            els.selectedFilesSection.style.display = 'none';
            els.fileCountBadge.textContent = '0 files (0 KB)';
            return;
        }

        els.selectedFilesSection.style.display = 'block';

        let totalSize = 0;
        state.filesToSend.forEach((file, index) => {
            totalSize += file.size;

            const row = document.createElement('div');
            row.className = 'file-item-row';
            row.innerHTML = `
                <div class="file-item-left">
                    <div class="file-item-icon">${getFileIcon(file.name)}</div>
                    <div class="file-item-details">
                        <div class="file-item-name" title="${file.name}">${file.name}</div>
                        <div class="file-item-size">${formatBytes(file.size)} &bull; ${file.type || 'Storage file'}</div>
                    </div>
                </div>
                <button type="button" class="file-item-remove-btn" data-index="${index}" title="Remove file">&times;</button>
            `;
            els.selectedFilesList.appendChild(row);
        });

        els.fileCountBadge.textContent = `${state.filesToSend.length} file(s) (${formatBytes(totalSize)})`;
        els.startTransferBtnText.textContent = `Beam ${state.filesToSend.length} File(s) Now (${formatBytes(totalSize)})`;

        els.selectedFilesList.querySelectorAll('.file-item-remove-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const idx = parseInt(btn.getAttribute('data-index'), 10);
                state.filesToSend.splice(idx, 1);
                renderSelectedFilesList();
            });
        });
    }

    // -------------------------------------------------------------------------
    // File Transfer Sending Pipeline
    // -------------------------------------------------------------------------
    function initiateSendTransfer() {
        if (state.filesToSend.length === 0) {
            showToast('Please select files from phone storage first!', 'warning');
            return;
        }

        if (!state.targetPeerId) {
            showToast('No receiver connected! Share your code or enter receiver code.', 'warning');
            return;
        }

        const metaList = state.filesToSend.map(f => ({
            name: f.name,
            size: f.size,
            type: f.type || 'application/octet-stream',
            lastModified: f.lastModified
        }));

        const totalBytes = state.filesToSend.reduce((acc, f) => acc + f.size, 0);

        const metaMessage = {
            type: 'file-meta',
            files: metaList,
            totalFiles: metaList.length,
            totalBytes: totalBytes,
            senderDevice: state.deviceType.name
        };

        sendWs(metaMessage);
        showToast('Waiting for receiver to accept...', 'info');
    }

    function handleTransferAccepted() {
        showToast('Receiver accepted! Starting transfer...', 'success');
        startSendingFiles();
    }

    function handleTransferDeclined() {
        showToast('Transfer was declined by receiver.', 'warning');
    }

    function handleTransferCancelled() {
        state.isTransferring = false;
        els.transferProgressModal.style.display = 'none';
        showToast('Transfer was cancelled.', 'warning');
    }

    async function startSendingFiles() {
        state.isTransferring = true;
        state.currentFileIndex = 0;
        state.transferredBytes = 0;
        state.totalBytes = state.filesToSend.reduce((acc, f) => acc + f.size, 0);
        state.transferStartTime = Date.now();
        state.lastBytesCheck = 0;
        state.lastTimeCheck = Date.now();

        // Check if WebRTC DataChannel is ready, otherwise automatically use Relay
        const isP2PReady = state.dataChannel && state.dataChannel.readyState === 'open';
        state.activeChannelType = isP2PReady ? 'webrtc' : 'relay';

        const badgeLabel = state.activeChannelType === 'webrtc' 
            ? 'WebRTC Direct P2P' 
            : 'Cloud Relay (Any Network)';

        openTransferProgressModal('Sending Files...', badgeLabel);

        for (let i = 0; i < state.filesToSend.length; i++) {
            if (!state.isTransferring) break;

            state.currentFileIndex = i;
            const file = state.filesToSend[i];

            els.activeFileName.textContent = file.name;
            els.transferFileCounter.textContent = `File ${i + 1} of ${state.filesToSend.length} (${formatBytes(file.size)})`;

            sendTransferControlMessage({
                type: 'start-file',
                index: i,
                name: file.name,
                size: file.size,
                mime: file.type
            });

            await sendSingleFileChunks(file);

            sendTransferControlMessage({
                type: 'end-file',
                index: i
            });
        }

        if (state.isTransferring) {
            state.isTransferring = false;
            sendTransferControlMessage({ type: 'transfer-complete' });
            els.transferProgressModal.style.display = 'none';
            sound.playChime();
            triggerHaptic();
            showToast('All files transferred successfully!', 'success');
        }
    }

    async function sendSingleFileChunks(file) {
        let offset = 0;

        while (offset < file.size && state.isTransferring) {
            // Flow control / backpressure check
            if (state.activeChannelType === 'webrtc' && state.dataChannel) {
                if (state.dataChannel.bufferedAmount > BUFFER_HIGH_WATERMARK) {
                    await waitForBufferDrain(state.dataChannel);
                }
            } else if (state.activeChannelType === 'relay' && state.ws) {
                if (state.ws.bufferedAmount > BUFFER_HIGH_WATERMARK) {
                    await new Promise(r => setTimeout(r, 40));
                }
            }

            const slice = file.slice(offset, offset + CHUNK_SIZE);
            const arrayBuffer = await slice.arrayBuffer();

            if (state.activeChannelType === 'webrtc' && state.dataChannel && state.dataChannel.readyState === 'open') {
                state.dataChannel.send(arrayBuffer);
            } else if (state.ws && state.ws.readyState === WebSocket.OPEN) {
                state.ws.send(arrayBuffer);
            }

            offset += arrayBuffer.byteLength;
            state.transferredBytes += arrayBuffer.byteLength;

            updateTransferProgressUI();
        }
    }

    function waitForBufferDrain(channel) {
        return new Promise((resolve) => {
            const onLow = () => {
                channel.removeEventListener('bufferedamountlow', onLow);
                resolve();
            };
            channel.addEventListener('bufferedamountlow', onLow);
            setTimeout(resolve, 400);
        });
    }

    function sendTransferControlMessage(msg) {
        if (state.activeChannelType === 'webrtc' && state.dataChannel && state.dataChannel.readyState === 'open') {
            state.dataChannel.send(JSON.stringify(msg));
        } else {
            sendWs(msg);
        }
    }

    // -------------------------------------------------------------------------
    // File Transfer Receiving Pipeline
    // -------------------------------------------------------------------------
    function handleIncomingFileMeta(message) {
        state.incomingMeta = message;

        els.incomingSenderName.textContent = message.senderDevice || 'Remote Sender';
        els.incomingMetaText.textContent = `wants to beam ${message.totalFiles} file(s) (${formatBytes(message.totalBytes)})`;

        els.incomingFilesPreview.innerHTML = '';
        message.files.forEach(f => {
            const item = document.createElement('div');
            item.className = 'file-item-row';
            item.innerHTML = `
                <div class="file-item-left">
                    <div class="file-item-icon">${getFileIcon(f.name)}</div>
                    <div class="file-item-details">
                        <div class="file-item-name">${f.name}</div>
                        <div class="file-item-size">${formatBytes(f.size)}</div>
                    </div>
                </div>
            `;
            els.incomingFilesPreview.appendChild(item);
        });

        sound.playAlert();
        triggerHaptic();
        els.incomingModal.style.display = 'flex';
    }

    function handleTransferControlMessage(msg) {
        switch (msg.type) {
            case 'start-file':
                state.receiveBuffer = [];
                state.receivedFileBytes = 0;
                els.activeFileName.textContent = msg.name;
                els.transferFileCounter.textContent = `File ${msg.index + 1} of ${state.incomingMeta ? state.incomingMeta.totalFiles : 1} (${formatBytes(msg.size)})`;
                break;

            case 'end-file':
                finalizeReceivedFile(msg.index);
                break;

            case 'transfer-complete':
                state.isTransferring = false;
                els.transferProgressModal.style.display = 'none';
                sound.playChime();
                triggerHaptic();
                showToast('All files saved to device storage!', 'success');
                break;
        }
    }

    function handleReceivedBinaryChunk(arrayBuffer) {
        if (!state.isTransferring) {
            state.isTransferring = true;
            state.transferredBytes = 0;
            state.totalBytes = state.incomingMeta ? state.incomingMeta.totalBytes : 0;
            state.transferStartTime = Date.now();
            const badge = state.isWebRTCConnected ? 'WebRTC Direct P2P' : 'Cloud Relay (Any Network)';
            openTransferProgressModal('Receiving Files...', badge);
        }

        state.receiveBuffer.push(arrayBuffer);
        state.receivedFileBytes += arrayBuffer.byteLength;
        state.transferredBytes += arrayBuffer.byteLength;

        updateTransferProgressUI();
    }

    function finalizeReceivedFile(fileIndex) {
        if (!state.incomingMeta || !state.incomingMeta.files[fileIndex]) return;

        const meta = state.incomingMeta.files[fileIndex];
        const blob = new Blob(state.receiveBuffer, { type: meta.type || 'application/octet-stream' });
        state.receiveBuffer = [];

        const receivedItem = {
            name: meta.name,
            size: meta.size,
            type: meta.type,
            blob: blob,
            url: URL.createObjectURL(blob),
            time: new Date()
        };

        state.receivedFiles.push(receivedItem);
        renderReceivedFilesList();

        if (state.autoDownload) {
            saveFileToDeviceStorage(receivedItem);
        }
    }

    function renderReceivedFilesList() {
        if (state.receivedFiles.length === 0) {
            els.receivedFilesCard.style.display = 'none';
            return;
        }

        els.receivedFilesCard.style.display = 'block';
        els.receivedFilesList.innerHTML = '';

        state.receivedFiles.forEach((file, index) => {
            const row = document.createElement('div');
            row.className = 'file-item-row';
            row.innerHTML = `
                <div class="file-item-left">
                    <div class="file-item-icon">${getFileIcon(file.name)}</div>
                    <div class="file-item-details">
                        <div class="file-item-name" title="${file.name}">${file.name}</div>
                        <div class="file-item-size">${formatBytes(file.size)} &bull; Ready in storage</div>
                    </div>
                </div>
                <div style="display: flex; gap: 6px;">
                    <button class="btn btn-sm btn-primary download-file-btn" data-index="${index}">Save</button>
                    ${navigator.share ? `<button class="btn btn-sm btn-outline share-file-btn" data-index="${index}">Share</button>` : ''}
                </div>
            `;
            els.receivedFilesList.appendChild(row);
        });

        els.receivedFilesList.querySelectorAll('.download-file-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const idx = parseInt(btn.getAttribute('data-index'), 10);
                saveFileToDeviceStorage(state.receivedFiles[idx]);
            });
        });

        els.receivedFilesList.querySelectorAll('.share-file-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
                const idx = parseInt(btn.getAttribute('data-index'), 10);
                const fileObj = state.receivedFiles[idx];
                try {
                    const file = new File([fileObj.blob], fileObj.name, { type: fileObj.type });
                    await navigator.share({ files: [file], title: fileObj.name });
                } catch (e) {
                    saveFileToDeviceStorage(fileObj);
                }
            });
        });
    }

    function saveFileToDeviceStorage(fileItem) {
        const a = document.createElement('a');
        a.href = fileItem.url;
        a.download = fileItem.name;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => document.body.removeChild(a), 100);

        showToast(`Saved "${fileItem.name}" to storage!`, 'success');
    }

    // -------------------------------------------------------------------------
    // Transfer Progress UI
    // -------------------------------------------------------------------------
    function openTransferProgressModal(title, channelBadge) {
        els.transferModalTitle.textContent = title;
        els.transferChannelBadge.textContent = channelBadge;
        els.transferProgressBar.style.width = '0%';
        els.transferPercent.textContent = '0%';
        els.transferSpeed.textContent = '0.0 MB/s';
        els.transferTimeRemaining.textContent = '--';
        els.transferProgressModal.style.display = 'flex';
    }

    function updateTransferProgressUI() {
        const percent = state.totalBytes > 0 
            ? Math.min(100, (state.transferredBytes / state.totalBytes) * 100)
            : 0;

        els.transferProgressBar.style.width = `${percent.toFixed(1)}%`;
        els.transferPercent.textContent = `${percent.toFixed(0)}%`;
        els.transferBytes.textContent = `${formatBytes(state.transferredBytes)} / ${formatBytes(state.totalBytes)}`;

        const now = Date.now();
        const timeDiff = (now - state.lastTimeCheck) / 1000;
        if (timeDiff >= 0.5) {
            const bytesDiff = state.transferredBytes - state.lastBytesCheck;
            const speed = bytesDiff / timeDiff;
            state.currentSpeed = speed;
            state.lastBytesCheck = state.transferredBytes;
            state.lastTimeCheck = now;

            els.transferSpeed.textContent = `${formatBytes(speed)}/s`;

            const remainingBytes = state.totalBytes - state.transferredBytes;
            const secondsLeft = speed > 0 ? remainingBytes / speed : 0;
            els.transferTimeRemaining.textContent = formatTime(secondsLeft);
        }
    }

    // -------------------------------------------------------------------------
    // Event Listeners & Binding
    // -------------------------------------------------------------------------
    function bindEventListeners() {
        els.pillSenderBtn.addEventListener('click', () => setRole('sender'));
        els.pillReceiverBtn.addEventListener('click', () => setRole('receiver'));

        els.switchToReceiverLink.addEventListener('click', () => setRole('receiver'));
        els.switchToSenderLink.addEventListener('click', () => setRole('sender'));

        if (els.chooseSenderCard) els.chooseSenderCard.addEventListener('click', () => setRole('sender'));
        if (els.chooseReceiverCard) els.chooseReceiverCard.addEventListener('click', () => setRole('receiver'));

        els.copyCodeBtn.addEventListener('click', () => {
            navigator.clipboard.writeText(state.roomId).then(() => showToast('Room code copied!', 'success'));
        });
        els.copyReceiverCodeBtn.addEventListener('click', () => {
            navigator.clipboard.writeText(state.roomId).then(() => showToast('Receiver code copied!', 'success'));
        });

        els.showQrBtn.addEventListener('click', () => {
            const shareUrl = getShareableURL(state.role, state.roomId);
            els.modalQrCodeText.textContent = `Room Code: ${state.roomId}`;
            renderQRCode(els.modalQrCodeContainer, shareUrl);
            els.qrModal.style.display = 'flex';
        });
        els.closeQrModal.addEventListener('click', () => {
            els.qrModal.style.display = 'none';
        });
        els.copyModalLinkBtn.addEventListener('click', () => {
            const shareUrl = getShareableURL(state.role, state.roomId);
            navigator.clipboard.writeText(shareUrl).then(() => showToast('Invite link copied!', 'success'));
        });

        const shareHandler = async () => {
            const shareUrl = getShareableURL(state.role, state.roomId);
            if (navigator.share) {
                try {
                    await navigator.share({
                        title: 'AnyDrop - File Transfer',
                        text: `Beam files on any network with AnyDrop (Room: ${state.roomId})`,
                        url: shareUrl
                    });
                } catch (e) {}
            } else {
                navigator.clipboard.writeText(shareUrl).then(() => showToast('Direct transfer link copied to clipboard!', 'success'));
            }
        };
        els.shareLinkBtn.addEventListener('click', shareHandler);
        els.shareReceiverLinkBtn.addEventListener('click', shareHandler);

        els.joinReceiverBtn.addEventListener('click', () => {
            const code = els.targetReceiverCodeInput.value.trim();
            if (code) joinRoom(code, 'sender');
        });
        els.joinSenderBtn.addEventListener('click', () => {
            const code = els.targetSenderCodeInput.value.trim();
            if (code) joinRoom(code, 'receiver');
        });

        els.genericFileInput.addEventListener('change', (e) => addFilesToQueue(e.target.files));
        els.mediaFileInput.addEventListener('change', (e) => addFilesToQueue(e.target.files));
        els.cameraFileInput.addEventListener('change', (e) => addFilesToQueue(e.target.files));

        els.dropZone.addEventListener('click', () => els.genericFileInput.click());
        els.dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            els.dropZone.classList.add('dragover');
        });
        els.dropZone.addEventListener('dragleave', () => els.dropZone.classList.remove('dragover'));
        els.dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            els.dropZone.classList.remove('dragover');
            if (e.dataTransfer.files) addFilesToQueue(e.dataTransfer.files);
        });

        window.addEventListener('paste', (e) => {
            if (e.clipboardData && e.clipboardData.files && e.clipboardData.files.length > 0) {
                addFilesToQueue(e.clipboardData.files);
                showToast('Pasted file from clipboard!', 'info');
            }
        });

        els.clearAllFilesBtn.addEventListener('click', () => {
            state.filesToSend = [];
            renderSelectedFilesList();
        });

        els.startTransferBtn.addEventListener('click', initiateSendTransfer);

        els.acceptTransferBtn.addEventListener('click', () => {
            els.incomingModal.style.display = 'none';
            sendWs({ type: 'transfer-accept' });
        });
        els.declineTransferBtn.addEventListener('click', () => {
            els.incomingModal.style.display = 'none';
            sendWs({ type: 'transfer-decline' });
        });

        els.cancelTransferBtn.addEventListener('click', () => {
            state.isTransferring = false;
            sendTransferControlMessage({ type: 'transfer-cancel' });
            els.transferProgressModal.style.display = 'none';
            showToast('Transfer cancelled', 'warning');
        });

        els.autoDownloadToggle.addEventListener('change', (e) => {
            state.autoDownload = e.target.checked;
        });

        els.saveAllReceivedBtn.addEventListener('click', () => {
            state.receivedFiles.forEach(f => saveFileToDeviceStorage(f));
        });

        els.themeToggleBtn.addEventListener('click', () => {
            document.body.classList.toggle('light-theme');
            document.body.classList.toggle('dark-theme');
            const isLight = document.body.classList.contains('light-theme');
            localStorage.setItem('anydrop_theme', isLight ? 'light' : 'dark');
        });

        els.howItWorksBtn.addEventListener('click', () => els.infoModal.style.display = 'flex');
        els.closeInfoModal.addEventListener('click', () => els.infoModal.style.display = 'none');
        els.closeInfoModalBtn.addEventListener('click', () => els.infoModal.style.display = 'none');

        els.brandBtn.addEventListener('click', () => {
            els.roleSelectorView.style.display = 'flex';
            els.senderView.style.display = 'none';
            els.receiverView.style.display = 'none';
        });

        parseHashParams();
    }

    function parseHashParams() {
        if (!window.location.hash) return;
        const hash = window.location.hash.substring(1);
        const params = new URLSearchParams(hash);
        const room = params.get('room');
        const role = params.get('role');

        if (room) state.roomId = room;
        if (role === 'sender' || role === 'receiver') {
            setRole(role);
        }
    }

    // -------------------------------------------------------------------------
    // Initialization
    // -------------------------------------------------------------------------
    async function init() {
        const savedTheme = localStorage.getItem('anydrop_theme');
        if (savedTheme === 'light') {
            document.body.classList.add('light-theme');
            document.body.classList.remove('dark-theme');
        }

        els.deviceIcon.textContent = state.deviceType.icon;
        els.deviceText.textContent = state.deviceType.name;

        bindEventListeners();
        connectSignalingServer();
        await fetchServerInfo();
        updateUIForActiveRoom();

        console.log('AnyDrop active on', state.deviceType.name, 'Base URL:', state.reachableBaseUrl);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
